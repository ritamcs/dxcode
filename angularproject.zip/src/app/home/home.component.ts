import { Component, OnInit } from '@angular/core';
import{Router} from '@angular/router';
import { BlogService } from '../blog.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private route:Router,private blogService: BlogService) { }
  userObj = {
    email:'',
    password: ''
  }
  tempObj:any;
  message: any;
  status: boolean = false;
  loginUser(){
    this.blogService.loginUser(this.userObj).subscribe(data => {
      console.log(data);
      this.tempObj = data;
      this.status = true;
      if(this.tempObj.success){
        localStorage.setItem('Authorization',this.tempObj.data);
        this.route.navigate(["dashboard"]);
      }else{
        //Message
        this.message = this.tempObj.msg;

      }
    })
  }
  ngOnInit() {
  }
  register()
  {
    this.route.navigate(["register"]);
  }
  images = [1, 2, 3].map(() => `https://picsum.photos/900/500?random&t=${Math.random()}`);

}
