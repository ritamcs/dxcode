import { Component, OnInit } from '@angular/core';
import { BlogService } from '../blog.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  constructor(private blogService:BlogService ) { }
  userInfo : any 
  password = false;
  userprofile={
    name:'',
    email:'',
    address:'',
    phone:''
  }
  passObj = {
    oldPassword: '',
    newPassword: '',
    confirmPassword: ''
  }
  ngOnInit() {
    this.getuserprofile();
  }
  getuserprofile(){
    this.blogService.getUserInfo().subscribe(data => {
      this.userInfo = data;
      this.userprofile = this.userInfo.data[0];
      
      //console.log(this.userprofile);
    })
  }
  changePassword(){
    this.password = true;
  }

  messageStatus:any

  passwordUpdate(){
    this.blogService.changepassword(this.passObj).subscribe(data => {
      this.messageStatus = data;

      if(this.messageStatus.success){
        this.messageStatus = this.messageStatus.msg
        this.password = false;
      }else{
        this.messageStatus = this.messageStatus.msg
      }
      setTimeout(() => {
        this.messageStatus = ''
      },2000);
    })
  }

  edit = false;
  userDetail:any;
  profilemsg:any;
  profileEdit(){
    
    this.edit = true;
    this.password=false;
    this.blogService.getuserfetch().subscribe(data=>{
     this.userDetail = data;
     this.userDetail = this.userDetail.data[0];
    //  console.log(this.userDetail);
    })
  }
  updateProfile()
  {
    let formData = {
      name : this.userDetail.name,
      address : this.userDetail.address,
      phone : this.userDetail.phone
    }


    this.blogService.profileupdate(formData).subscribe(data=>{
      // this.edit = false;
      // this.getuserprofile();
      this.profilemsg = data;

      if(this.profilemsg.success){
        this.profilemsg = this.profilemsg.msg
        this.edit = false;
        this.getuserprofile();
      }else{
        this.profilemsg = this.profilemsg.msg
      }
      setTimeout(() => {
        this.profilemsg = ''
      },2000);
    })
   
  }
}
