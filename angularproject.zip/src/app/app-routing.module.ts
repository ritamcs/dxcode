import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register/register.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ProfileComponent } from './profile/profile.component';
import { ViewpostComponent } from './viewpost/viewpost.component';
import { PurchasedpostComponent } from './purchasedpost/purchasedpost.component';
import { AddpostComponent } from './addpost/addpost.component';
import { ManagepostComponent } from './managepost/managepost.component';

const routes: Routes = [

  {path:"",redirectTo:"home",pathMatch:"full"},
  {path:"home",component:HomeComponent},
  {path:"register",component:RegisterComponent},
  {path:"dashboard",redirectTo:"dashboard/profile",pathMatch:"full"},

  {path:"dashboard",component:DashboardComponent,
  children:[

    {path:"profile",component:ProfileComponent},
    {path:"addpost",component:AddpostComponent},
     {path:"viewpost",component:ViewpostComponent},
     {path:"managepost",component:ManagepostComponent},
     {path:"purchasedpost",component:PurchasedpostComponent}
  ]
},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
