import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BlogService } from '../blog.service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private route:Router,private blogService:BlogService) { }
  userInfo : any;
  blogCount:any;
  
  ngOnInit() {
    if(localStorage.getItem('Authorization')){
      this.blogService.getUserInfo().subscribe(data => {
        this.userInfo = data;
        this.blogService.getPostCount().subscribe(response => {
          this.blogCount = response;
          this.blogService.getblogCount(this.blogCount.data);
          this.blogService.message.subscribe(length=>{
            this.blogCount = length;
          });
        })
       
      })
    }else{
      this.route.navigate(["home"]);

    }



  
  }
 
  logout(){
     localStorage.removeItem('Authorization');
    this.route.navigate(["home"]);
  }
}
