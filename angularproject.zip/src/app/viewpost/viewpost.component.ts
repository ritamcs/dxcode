import { Component, OnInit } from '@angular/core';
import { BlogService } from '../blog.service';
@Component({
  selector: 'app-viewpost',
  templateUrl: './viewpost.component.html',
  styleUrls: ['./viewpost.component.css']
})
export class ViewpostComponent implements OnInit {

  constructor(private blogService:BlogService) { }
  allposts:any;
  posts=[];
  ngOnInit() {
    this.blogService.getallpostview().subscribe(data=>{
     this.allposts = data;
    //  this.posts.push(this.allposts);
      this.allposts = this.allposts.data;
      console.log(this.allposts);
    })
  }
  


}
