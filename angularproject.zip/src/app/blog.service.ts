import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable , BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class BlogService {
  constructor(private httpService: HttpClient) { }
  posts='';

  blogsLength = new BehaviorSubject(this.posts); //3 -> 4 
  message = this.blogsLength.asObservable();

  
  getblogCount(data){ //4
    this.blogsLength.next(data); //4
  }
  registerUser(userObj) {
    let httpHeaders = new HttpHeaders ({
      'Content-Type': 'application/json',
      // 'Authorization': 'Bearer validToke.' 
    });
    return this.httpService.post('http://localhost:3000/api/user/register', userObj, { headers: httpHeaders });
  }

  loginUser(userObj){
    let httpHeaders = new HttpHeaders ({
      'Content-Type': 'application/json',
      // 'Authorization': 'Bearer validToke.' 
    });
    return this.httpService.post('http://localhost:3000/api/user/login', userObj, { headers: httpHeaders });
  }

  getUserInfo(){
    let httpHeaders = new HttpHeaders ({
      'Content-Type': 'application/json',
      'Authorization': localStorage.getItem('Authorization') 
    });
    return this.httpService.post('http://localhost:3000/api/userAuth/profile', {} , { headers: httpHeaders });
  }

  getPostCount(){
    let httpHeaders = new HttpHeaders ({
      'Content-Type': 'application/json',
      'Authorization': localStorage.getItem('Authorization') 
    });
    return this.httpService.post('http://localhost:3000/api/postAuth/postcount', {} , { headers: httpHeaders });
  }

  getallpostview(){

    let httpHeaders=new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': localStorage.getItem('Authorization') 
     });

    return this.httpService.post('http://localhost:3000/api/postAuth/viewallposts', {} , { headers: httpHeaders });

    
  }

  addpost(postobj){

    let httpHeaders=new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': localStorage.getItem('Authorization') 
     });

    return this.httpService.post('http://localhost:3000/api/postAuth/postinsert', postobj , { headers: httpHeaders });

    
  }


  getonlyuserPost(){

    let httpHeaders=new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': localStorage.getItem('Authorization') 
     });

    return this.httpService.post('http://localhost:3000/api/postAuth/view', {} , { headers: httpHeaders });

    
  }

  deletePost(formdata){
    let httpHeaders=new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': localStorage.getItem('Authorization') 
     });
    return this.httpService.post('http://localhost:3000/api/postAuth/usersinglepostdelete', formdata , { headers: httpHeaders });
  }

  getsinglePostfetch(formdata){
    let httpHeaders=new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': localStorage.getItem('Authorization') 
     });
    return this.httpService.post('http://localhost:3000/api/postAuth/usersinglepostfetch', formdata , { headers: httpHeaders });
  }

  postedit(formdata){
    let httpHeaders=new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': localStorage.getItem('Authorization') 
     });
    return this.httpService.post('http://localhost:3000/api/postAuth/postedit', formdata , { headers: httpHeaders });
  }

  changepassword(formdata){
    let httpHeaders=new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': localStorage.getItem('Authorization') 
     });
    return this.httpService.post('http://localhost:3000/api/userAuth/changepassword', formdata , { headers: httpHeaders });
  }

  getuserfetch(){
    let httpHeaders=new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': localStorage.getItem('Authorization') 
     });
    return this.httpService.post('http://localhost:3000/api/userAuth/profile', {} , { headers: httpHeaders });
  }

  profileupdate(formdata){
    let httpHeaders=new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': localStorage.getItem('Authorization') 
     });
    return this.httpService.post('http://localhost:3000/api/userAuth/profileupdate', formdata , { headers: httpHeaders });
  }
}
