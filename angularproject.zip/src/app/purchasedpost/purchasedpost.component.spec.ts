import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PurchasedpostComponent } from './purchasedpost.component';

describe('PurchasedpostComponent', () => {
  let component: PurchasedpostComponent;
  let fixture: ComponentFixture<PurchasedpostComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PurchasedpostComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PurchasedpostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
