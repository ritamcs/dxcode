import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-purchasedpost',
  templateUrl: './purchasedpost.component.html',
  styleUrls: ['./purchasedpost.component.css']
})
export class PurchasedpostComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
