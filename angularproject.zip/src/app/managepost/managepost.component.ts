import { Component, OnInit } from '@angular/core';
import { BlogService } from '../blog.service';

@Component({
  selector: 'app-managepost',
  templateUrl: './managepost.component.html',
  styleUrls: ['./managepost.component.css']
})
export class ManagepostComponent implements OnInit {

  constructor(private blogService:BlogService) { }
  posts:any;
  edit = false;
  ngOnInit() {
   this.getAllPosts();
  }

  getAllPosts(){
    this.blogService.getonlyuserPost().subscribe(data=>{
      this.posts = data;
      this.posts = this.posts.data;
    })
  }
  
  checkData:any;
  deletemsg:any;
  postDelete(id){
    let data = confirm('Are you sure?')
    if(data){
      let formdata = {
        _id : id
      }
      this.blogService.deletePost(formdata).subscribe(data=>{
      //  console.log(data)
      //  this.getAllPosts();
      this.deletemsg = data;
        

      this.blogService.getPostCount().subscribe(response => {
        this.checkData = response;
        this.blogService.getblogCount(this.checkData.data);
      })


        if(this.deletemsg.success){
          this.deletemsg = this.deletemsg.msg
      
          this.getAllPosts();
        }else{
          this.deletemsg = this.deletemsg.msg
        }
        setTimeout(() => {
          this.deletemsg = ''
        },2000);
      })
    }

    
  }

  postsDetail:any;
  postEdit(id){
    let formdata = {
      _id : id
    }
    this.edit = true;
    this.blogService.getsinglePostfetch(formdata).subscribe(data=>{
     this.postsDetail = data;
     this.postsDetail = this.postsDetail.data[0];
     console.log(this.postsDetail);
    })
  }
postmsg:any;
  updatePost(){
    this.blogService.postedit(this.postsDetail).subscribe(data=>{
      // this.edit = false;
      // this.getAllPosts();
      this.postmsg = data;

      if(this.postmsg.success){
        this.postmsg = this.postmsg.msg
        this.edit = false;
        this.getAllPosts();
      }else{
        this.postmsg = this.postmsg.msg
      }
      setTimeout(() => {
        this.postmsg = ''
      },2000);
    })
  }
}



// data = { data:'asdasd',success:'asdasd' };
// postsde = data;
// postsde = postsde.data
