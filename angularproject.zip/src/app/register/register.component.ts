import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BlogService } from '../blog.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {           
  constructor(private route: Router,private blogService:BlogService) { }
  userObj = {
    name: '',
    email: '',
    password: '',
    address: '',
    phone: ''
  }
  tempObj: any;
  message: any;
  status: boolean = false;
  ngOnInit() {
  }
  register(){
    
    this.blogService.registerUser(this.userObj).subscribe(data => {
      this.tempObj = data;

      // console.log(data);
      this.status = true;
      if(this.tempObj.success){
         this.route.navigate(["home"]);
      }else{
        this.message = this.tempObj.msg;
      }
    })
  }
  home() {
    this.route.navigate(["home"]);
  }

  // authorization(){
  //   this.blogService.checkAuthUser().subscribe(data => {
  //     console.log(data)
  //   }
  // }

  images = [1, 2, 3].map(() => `https://picsum.photos/900/500?random&t=${Math.random()}`);
}
