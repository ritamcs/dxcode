import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { BlogService } from '../blog.service';

@Component({
  selector: 'app-addpost',
  templateUrl: './addpost.component.html',
  styleUrls: ['./addpost.component.css']
})
export class AddpostComponent implements OnInit {
  constructor(private route: Router,private blogService:BlogService) { }
  ngOnInit() {
  }
  tempObj: any = {
    data:[],
    success:false,
    msg:''
  }
  message: any;
  status: boolean = false;
  postdetails={
    title:'',
    description:'',
  }
  checkData:any;
  addPost(){
    if(this.postdetails.title != "" && this.postdetails.description != ""){
      this.blogService.addpost(this.postdetails).subscribe(data => {
        this.tempObj = data;
        this.blogService.getPostCount().subscribe(response => {
          this.checkData = response;
          this.blogService.getblogCount(this.checkData.data);
        })
        this.status = true;
        if(this.tempObj.success){
          this.postdetails={
            title:'',
            description:'',
          }
          this.message = this.tempObj.msg;
          setTimeout(()=>{
            this.message = '';
            this.status = false;
                },2000)
        }else{
          this.message = this.tempObj.msg;
        }
      })
    }else{
      this.status = true;
      this.message = 'Please Fill Up All The Fields'
    }
  }
}
