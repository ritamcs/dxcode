const express= require('express');
const app= express();
var cors = require('cors');
app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(cors());

const userRoutes= require('./user/userRoutes');

app.use('/api/user',userRoutes);

const userAuth= require('./user/userAuthRoutes');

app.use('/api/userAuth',userAuth);

const postAuth= require('./user/postAuthRoutes');

app.use('/api/postAuth',postAuth);

app.listen(3000,()=>{
console.log('Server is running');    
})
