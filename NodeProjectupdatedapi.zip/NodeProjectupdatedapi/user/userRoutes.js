const express = require('express');
const router = express.Router();

const userQueries = require('./userqueries');


router.post('/register',(req,res) => {
    userQueries.register(req,res);
});


router.post('/login',(req,res) => {
    userQueries.login(req,res);
})

module.exports = router;