require('../mongodb/connection'); 
const usermodel = require('./usermodel'); 
const jwt = require('jsonwebtoken');


const userqueries = {
    register : (req,res) => {
    if(req.body.name != "" && req.body.email != "" && req.body.password != "" && req.body.address != "" && req.body.phone != ""){
    
        let userObj = {
            name: req.body.name,
            email: req.body.email,
            password:req.body.password,
            address: req.body.address,
            phone:req.body.phone
        }
        // Email-ID Check \\
        usermodel.find({email:req.body.email})
        .then(resp => {
            if(resp.length != 0){
             return res.json({
                    data : [],
                    success: false,
                    msg : 'Email Exists'
             })
            }
            else{
                usermodel.create(userObj)
                nameObj = {
                    name:userObj.name
                }
                finalArray = [];
                finalArray.push(nameObj);
                return res.json({
                    data : finalArray,
                    success: true,
                    msg : 'Registered Successfully'
             })
            }
        })
        .catch(err => {
            return res.json({
                data : [],
                success: false,
                msg : 'Error'
            })
        })
    }
    else{
        return res.json({
            data : [],
            success: false,
            msg : 'Please Fill Up All The Fields'
        })
    }
    },
    login: (req,res)=>{
        if(req.body.email && req.body.password){
            usermodel.find({email:req.body.email,password:req.body.password})
            .then(resp => {
                if(resp.length == 0){
                    return res.json({
                        data : [],
                        success: false,
                        msg : 'Invalid Credentials'
                    })
                }else{
                    // let userObj = {
                    //     name: resp[0].name,
                    //     email: resp[0].email,
                    //     address: resp[0].address,
                    //     phone:resp[0].phone
                    // }
                    let userDetails = Object.assign({},resp[0]);
                    // let userObj = Object.assign({},userDetails._doc);
                    var token = jwt.sign(userDetails, 'abcdef123456');
                    return res.json({
                        data : token,
                        success: true,
                        msg : 'Verified Login'
                    })
                }
            })
            .catch(err => {
                return res.json({
                    data : [],
                    success: false,
                    msg : 'Error'
                })
            })
        }else{
            return res.json({
                data : [],
                success: false,
                msg : 'Please Fill up All Fields'
            })
        }
    }
}

module.exports = userqueries;