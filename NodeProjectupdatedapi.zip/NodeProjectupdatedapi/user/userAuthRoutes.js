const express = require('express');
const router = express.Router();
const userAuthQueries = require('./userAuthQueries');
const jwt= require('jsonwebtoken');

//create Middileware
router.use((req, res, next) => {
    const token = req.headers['authorization'];
    if (!token) {
        return res.json({
            data: [],
            success: false,
            message: "Please Provide Token"
        })
    }
    jwt.verify(token, 'abcdef123456', (err, decoded) => {
        if (err) {
            return res.json({
                data: [],
                success: false,
                message: "Please Provide Valid Token"
            })
        }
        let userid = decoded._doc._id;
        req.body.userid = userid;
        next();
    })
})



router.post('/profile',(req,res) => {
    userAuthQueries.getprofile(req,res);
});


router.post('/profileupdate',(req,res) => {
    userAuthQueries.profileupdate(req,res);
});


module.exports = router;