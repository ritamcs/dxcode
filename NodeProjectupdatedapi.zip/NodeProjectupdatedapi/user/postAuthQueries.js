require('../mongodb/connection'); //Whole page Require
const postmodel = require('./postmodel'); //Require module exports
const mongoose = require('mongoose');

const postqueries = {

    postinsert : (req,res) => {
        // let userid = mongoose.Types.ObjectId(req.body.userid);
        if(req.body.title != "" && req.body.description != ""){
            let postObj = {
                title: req.body.title,
                description: req.body.description,
                userid:req.body.userid,
                postid:req.body.postid
            }
            postmodel.create(postObj)
            .then(resp => {
                return res.json({
                    data : [],
                    success: true,
                    msg : 'Post Inserted'
                })
            })
            .catch(err => {
                return res.json({
                    data : [],
                    success: false,
                    msg : 'Error'
                })
            })
        }else{
            return res.json({
                data : [],
                success: false,
                msg : 'Please Fill Up All The Fields'
            })
        }
       
    },
    getUserPosts : (req,res) => {
       
        postmodel.find({userid:req.body.userid})
        .then(resp => {
            return res.json({
                data : resp,
                success: true,
                msg : 'View User Post Information'
            })
        })
        .catch(err => {
            return res.json({
                data : [],
                success: false,
                msg : 'Error'
            })
        })
    },


    getallUserPosts : (req,res) => {
       
        postmodel.find({})
        .then(resp => {
            return res.json({
                data : resp,
                success: true,
                msg : 'View All User Post Information'
            })
        })
        .catch(err => {
            return res.json({
                data : [],
                success: false,
                msg : 'Error'
            })
        })
    },

    userpostedit: (req,res) => {
        //let userid = mongoose.Types.ObjectId(req.body.userid);
        let userid = req.body.userid;
        let postid = mongoose.Types.ObjectId(req.body._id);
        let updateObj = {
            title: req.body.title,
            description: req.body.description
        }
        if(updateObj.title!="" && updateObj.description!=""){
        postmodel.findOneAndUpdate({_id:postid}, updateObj, {upsert:true})
        .then(resp => {
            return res.json({
                data : [],
                success: true,
                msg : 'User Posts Information Updated'
            })
        })
        .catch(err => {
            return res.json({
                data : [],
                success: false,
                msg : 'Error'
            })
        })
    }
    else
    {
        return res.json({
            data : [],
            success: false,
            msg : 'Please Fill Up All The Fields'
        })
    }
    },


    postcount : (req,res) => {
        
        if((req.body.userid)!=null){
        postmodel.find({userid:req.body.userid})
        
        .then(resp => {
            return res.json({
                data : (resp.length),
                success: true,
                msg : 'User Post Count Information'
            })
        })
        .catch(err => {
            return res.json({
                data : [],
                success: false,
                msg : 'Error'
            })
        })

     }
     else{
        return res.json({
            data : [],
            success: false,
            msg : 'Error'
        })

     }
    },
    usersinglepostfetch : (req,res) => {
        //let user_id = req.body.userid;
        let post_id = mongoose.Types.ObjectId(req.body._id);
        if(post_id){
        postmodel.find({_id:post_id})
        
        .then(resp => {
            return res.json({
                data : resp,
                success: true,
                msg : 'View Post Information'
            })
        })
        .catch(err => {
            return res.json({
                data : [],
                success: false,
                msg : 'Error'
            })
        })
    }

    else{
        return res.json({
            data : [],
            success: false,
            msg : 'Error'
        })
       }
    },

    usersinglepostdelete : (req,res) => {
        //let user_id = req.body.userid;
        let post_id = mongoose.Types.ObjectId(req.body._id);
        if(post_id){
        postmodel.find({_id:post_id }).remove().exec()
        .then(resp => {
            return res.json({
                data : [],
                success: true,
                msg : 'Post Deleted'
            })
        })
        .catch(err => {
            return res.json({
                data : [],
                success: false,
                msg : 'Error'
            })
        })
    }

    else{
        return res.json({
            data : [],
            success: false,
            msg : 'Error'
        })
       }
    },


    usersallpostdelete : (req,res) => {
        let user_id = req.body.userid;
        if(user_id){
        postmodel.find({ userid:user_id }).remove().exec()
        .then(resp => {
            return res.json({
                data : [],
                success: true,
                msg : 'Post Deleted'
            })
        })
        .catch(err => {
            return res.json({
                data : [],
                success: false,
                msg : 'Error'
            })
        })
    }

    else{
        return res.json({
            data : [],
            success: false,
            msg : 'Error'
        })
       }
    },
}

module.exports = postqueries;