require('../mongodb/connection');
const usermodel = require('./usermodel');
const mongoose = require('mongoose');
const userqueries = {

    getprofile : (req,res) => {
        let userid = mongoose.Types.ObjectId(req.body.userid);
        usermodel.find({_id:userid})
        .then(resp => {
            return res.json({
                data : resp,
                success: true,
                msg : 'User Information Generated'
            })
        })
        .catch(err => {
            return res.json({
                data : [],
                success: false,
                msg : 'Error'
            })
        })
    },
    profileupdate: (req,res) => {
        //console.log(req.body)
        let userid = mongoose.Types.ObjectId(req.body.userid);
        if(req.body.email && req.body.password)
        {
            return res.json({
                data : [],
                success: false,
                msg : 'You Cannot Update Email And Password'
            })
        }else{
            let updatedata = {
                name :req.body.name,
                address : req.body.address,
                phone: req.body.phone
            }
            if(updatedata.name!="" && updatedata.address!="" && updatedata.phone!="")
            {
            //console.log(updatedata);
            usermodel.findOneAndUpdate({_id:userid},updatedata,{upsert:true})
            .then(resp => {
                return res.json({
                    data : [],
                    success: true,
                    msg : 'User Information Updated'
                })
            })
            .catch(err => {
                return res.json({
                    data : [],
                    success: false,
                    msg : 'Error'
                })
            })
        }
        else{
            return res.json({
                data : [],
                success: false,
                msg : 'Please Fill Up All The Fields'
            })
        }
        }
    },
    updateUserPassword: (req,res) => {
        //Old Password, New Password, Confirm Password
        if(req.body.oldPassword && req.body.newPassword && req.body.confirmPassword){
            //Step 1 : Check Old Password (match)
            let oldPass = req.body.oldPassword;
            usermodel.find({_id:mongoose.Types.ObjectId(req.body.userid), password:oldPass})
            .then(response => {
                if(response.length != 0){
                    //Step 2 : Match New & Confirm
                    if(req.body.newPassword == req.body.confirmPassword){
                        //Update New Password
                        let updateObj = {
                            password : req.body.newPassword
                        }
                        usermodel.findOneAndUpdate({_id:mongoose.Types.ObjectId(req.body.userid)}, updateObj, {upsert:true})
                        .then(resp => {
                            return res.json({
                                data : [],
                                success: true,
                                msg : 'Password  Updated'
                            })
                        })
                        .catch(err => {
                            return res.json({
                                data : [],
                                success: false,
                                msg : 'Please Try Again'
                            })
                        })
                    }else{
                        return res.json({
                            data : [],
                            success: false,
                            msg : 'Password Do Not Match'
                        })
                    }
                }else{
                    return res.json({
                        data : [],
                        success: false,
                        msg : 'Old Password Do Not Match'
                    })
                }
            })

        }else{
            return res.json({
                data : [],
                success: false,
                msg : 'Please Provide All The Fields'
            })
        }



        //console.log("asasassasas");
        // let userid = mongoose.Types.ObjectId(req.body.userid);
        // let updateObj = {
        //     password : req.body.password
        // }
        // usermodel.findOneAndUpdate({_id:userid}, updateObj, {upsert:true})
        // .then(resp => {
        //     return res.json({
        //         data : [],
        //         success: true,
        //         msg : 'Password  Updated'
        //     })
        // })
        // .catch(err => {
        //     return res.json({
        //         data : [],
        //         success: false,
        //         msg : 'Error'
        //     })
        // })
    }
  }

  module.exports=userqueries;