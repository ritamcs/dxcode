require('../mongodb/connection');
const usermodel=require('./usermodel');
const jwt= require('jsonwebtoken');

const userQueries={
    findAllUser : (req,res) => {
        usermodel.find({})
        .then(resp => {
            return res.json({
                data : resp,
                success: true,
                msg : 'All user information generated'
            })
        })
        .catch(err => {
            return res.json({
                data : [],
                success: false,
                msg : 'Error'
            })
        })
    },
// Register Function\\
register:(req,res)=>{
let userdetails={
name:req.body.name,
email:req.body.email,
password:req.body.password,
address:req.body.address,
phone:req.body.phone,
}
usermodel.find({email:req.body.email})
.then(resp => {
    if(resp!=null){
        return res.json({
            data : [],
            success: false,
            msg : "Email Exists"
        })
    }
    else
    {
        usermodel.create(userdetails)
        return res.json({
            data : [],
            success: true,
            msg : "Registered Successfully"
        })
    }
  })
  .catch(err => {
    return res.json({
        data : [],
        success: false,
        msg : 'Error'
    })
})



},

//Login Function\\    
logincheck:(req,res)=>{

if(req.body.email && req.body.password){
usermodel.find({email:req.body.email,password: req.body.password})
.then(resp => {
if(resp.lenghth==0)
{
return res.json({
 data:[],
 success:false,
 message:"Please Provide Credential"

})
}
else{
 //Token Generate\\   
 let userdetails=Object.assign({},resp[0]);
 const token= jwt.sign(userdetails,dx007);
 return res.json({
    data : token,
    success: true,
    msg : 'Verified Login'
})
}
})
.catch(err => {
    return res.json({
        data : [],
        success: false,
        msg : 'Error'
    })
})
}
else{
    return res.json({
        data : [],
        success: false,
        msg : 'Please Fill up All Fields'
    })
}
}






}


module.exports=userQueries;