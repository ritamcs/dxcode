const express = require('express');
const router = express.Router();
const postQueries = require('./postAuthQueries');
const jwt = require('jsonwebtoken');

//JWT Verification
router.use((req, res, next) => {
    var token = req.headers['authorization'];
    if (!token){
        return res.json({
            data:[],
            success:false,
            msg: 'Please Provide Token'
        })
    }
    jwt.verify(token, 'abcdef123456', (err, decoded) => {
      if (err){
        return res.json({
            data:[],
            success:false,
            msg: 'Please Provide Valid Token'
        })
      }
      //console.log(decoded);
      let userid=decoded._doc._id;
      req.body.userid = userid;
      next();
    });
});


router.post('/postinsert',(req,res) => {
    postQueries.postinsert(req,res);
});

    router.post('/view',(req,res) => {
    postQueries.getUserPosts(req,res);
});


    router.post('/viewallposts',(req,res) => {
        postQueries.getallUserPosts(req,res);
    });

router.post('/postedit',(req,res) => {
    postQueries.userpostedit(req,res);
});


router.post('/postcount',(req,res) => {
    postQueries.postcount(req,res);
});


router.post('/usersinglepostfetch',(req,res) => {
    postQueries.usersinglepostfetch(req,res);
});



router.post('/usersinglepostdelete',(req,res) => {
    postQueries.usersinglepostdelete(req,res);
});


router.post('/usersallpostdelete',(req,res) => {
    postQueries.usersallpostdelete(req,res);
});
module.exports = router;