const express= require('express');
const router=express.Router();
const userQueries=require('./userQueries');

//http://localhost:3000/api/user/register
router.post('/register',(req,res)=>{
    userQueries.register(req,res);   
   })
   
//http://localhost:3000/api/user/login
router.post('/login',(req,res)=>{
userQueries.logincheck(req,res);   
})

 module.exports=router;
