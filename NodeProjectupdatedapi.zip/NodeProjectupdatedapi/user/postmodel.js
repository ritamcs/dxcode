const mongoose = require('mongoose');

const postInfoSchema = mongoose.Schema({
   
    title : { type: String , required:true },
    description: { type: String , required:true},
    userid: { type: String , required:true},
    //postid:  {type: String , required:true}

})

const postinfo = mongoose.model('posts',postInfoSchema);
module.exports = postinfo;

