const mongoose = require('mongoose'); //Require Package

mongoose.connect('mongodb://localhost:27017/appiness',{ useNewUrlParser: true })
.then(resp => {
    console.log('MongoDB is connected');
})
.catch(err => {
    console.log('Error in connection');
})